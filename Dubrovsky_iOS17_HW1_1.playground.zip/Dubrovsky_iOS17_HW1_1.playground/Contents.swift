import UIKit

var greeting = "Hello, Netology"
